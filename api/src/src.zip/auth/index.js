'use strict'
const passport = require('passport');

const localAuth = require('./local-auth');

passport.use('local', localAuth);
passport.serializeUser((user, done) => {
  done(null, user.user_id);
});

passport.deserializeUser(async (userid, done) => {
  try {
    const user_info = await db.findUserById(userid);
    done(null, user_info);
  } catch (err) {
    done(err);
  }
});

module.exports = {
  passport: passport
};


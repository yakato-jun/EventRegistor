'use strict'
const express = require('express');
const router = express.Router();

const rootRouter = require('./root');
const userRouter = require('./user');
const loginRouter = require('./login');

console.log('router/index.js');

router.use((req, res, next) => {
  // log に ログインされているかを出力する
  console.log('isAuthenticated:', req.isAuthenticated());
  next();
});

router.use('/', rootRouter);
router.use('/user', userRouter);
router.use('/login', loginRouter);

module.exports = router;